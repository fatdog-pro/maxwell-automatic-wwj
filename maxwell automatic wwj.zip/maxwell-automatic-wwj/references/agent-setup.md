# 智能体接入

作者：抖音 萌猪过河

需要 Windows 交互式桌面、带 Maxwell 的 Electronics Desktop、Python 和本包依赖。路径均可替换；AEDT 的版本独立于 Workbench。默认 Student，商业版增加 `--commercial` 并填写其实际安装根与版本。

## 先独立准备可见桌面

在 **MCP 进程链外的独立本地 PowerShell 终端**运行：

```powershell
& 'E:/MaxwellAgent/.venv/Scripts/python.exe' -B -X utf8 `
  'E:/MaxwellAgent/maxwell-automatic-wwj/scripts/prepare_desktop.py' `
  --aedt-root 'E:/AnsysEMStudent/v252/AnsysEM' `
  --version 2025.2
```

该工具通过官方 API 启动或附着唯一可见桌面，完成核验后断开客户端并保留窗口。多个桌面或无法核实兼容身份时停止，不自动关闭用户窗口。第一次初始化弹窗由用户手动完成。

准备工具不能通过同一 MCP 服务的子进程来执行。某些 MCP 客户端关闭会话时会清理进程链，其新启动的 AEDT 也可能被关闭。独立准备桌面后 MCP 只附着该桌面，避免将原生主窗口挂在该生命周期下；不修改 SDK、Windows Job 隔离或安全策略。

纯 MCP 智能体需要先由本机独立终端完成准备。没有窗口时，`start_actuator3d` 应拒绝并返回准备命令；不连续重试，不回退新开桌面。

## 内置示例：本地 CLI 求解

准备好桌面后运行：

```powershell
& 'E:/MaxwellAgent/.venv/Scripts/python.exe' -B -X utf8 `
  'E:/MaxwellAgent/maxwell-automatic-wwj/scripts/replay_actuator3d.py' `
  --output 'E:/MaxwellAgent/runs/actuator3d-single-new-run' `
  --aedt-root 'E:/AnsysEMStudent/v252/AnsysEM' `
  --version 2025.2 --require-existing
```

输出目录必须是新的、全 ASCII 绝对路径。`--require-existing` 只附着已有桌面；独立本地 CLI 可以不带此参数，由固定脚本在没有会话时启动一个可见桌面。若调用来源也受 MCP 进程生命周期管理，仍应先独立准备并保留此参数。

## 内置示例：本地 stdio MCP

修改 [mcp.example.json](../mcp.example.json) 中 Python、脚本、工作目录、AEDT 根、版本和版别，再填入客户端。本服务使用 stdio，不是 HTTP/SSE 地址；标准输出仅用于协议。

| 工具 | 参数 | 行为 |
|---|---|---|
| `inventory` | 无 | 读取依赖、安装和进程/窗口信息，不附着或求解 |
| `start_actuator3d` | 无 | 附着已准备的唯一桌面，在新目录启动固定单工况并返回任务标识 |
| `job_status` | `job_id` | 读取返回任务的阶段、终态、验收和输出路径 |

任务 `kind` 为 `actuator3d_single`。启动工具不接受代码、物理参数或附加工况。调用一次 `start_actuator3d` 后持续查询同一任务；`started` 不等于求解成功。最后核对本次数值、原生消息、验收和保存复读结果，再展示图片与工程。

上述三个工具是本包当前封装的示例入口。更换包后重连 MCP 以刷新工具列表。豆包客户端本身未实测，通用 stdio 测试不替代该客户端实际接入。

## 用户自定义 Maxwell 任务

智能体具备本地脚本执行能力时，按 [SKILL.md](../SKILL.md) 的自定义任务路线编写和运行官方 PyAEDT / AEDT 脚本，可从新模型或用户已有工程的新副本开始。复用会话守卫与接入方法，并为本次模型设置和验证材料、激励、边界、网格、求解及输出；固定示例的物理参数与验收公式只适用于该示例。

保持同一可见桌面并使用任务专用输出目录。若脚本执行本身由 MCP 命令工具提供，同样先在该 MCP 进程链外准备桌面，再通过 API 附着，避免客户端退出时连带关闭新建的原生桌面。

仅连接本包三个 MCP 工具时，尚不能提交新模型或修改参数。要完成这类任务，目标智能体还需要本地脚本执行能力，或另行实现并验证针对该任务的 MCP 工具。skill 的适用工作流与现有 MCP 工具的实现范围应分别说明。

## 运行边界

会话守卫读取进程和窗口元数据、取得共享锁，并在建模、求解、后处理与复读阶段核对唯一可见桌面。通过官方 `RestoreWindow` 恢复同一窗口；不模拟输入、不解除项目锁、不关闭用户会话。

Student 2025 R2 使用旧启动参数及本机 insecure gRPC；脚本按已核对的 [PyAEDT 官方通信说明](https://aedt.docs.pyansys.com/version/stable/Getting_started/ClientServer.html)处理。其他版本的传输设置须按实际版本核对，不能只更改版本数字就宣称兼容。

官方 PyAEDT/AEDT API 执行建模与求解，skill 提供可复用的接入、任务实施与验证方法；本包 MCP 当前将内置固定示例封装为智能体工具。MCP 本身不增加求解精度或许可权限；本包 MCP 不是 Ansys 官方 MCP 服务。
