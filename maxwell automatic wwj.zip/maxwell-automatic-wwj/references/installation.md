# 安装与迁移

作者：抖音 萌猪过河

## 软件与依赖

Maxwell 属于独立 Electronics Desktop。本机运行环境为 **Electronics Desktop Student 2025 R2**；Workbench 的安装和版本不能说明 Maxwell 已安装。Student 原生程序为 `ansysedtsv.exe`，商业版为 `ansysedt.exe`；`--aedt-root` 指向包含对应程序的目录。

截至 2026-10-08，[官方下载页](https://ansys.synopsys.com/academic/students/ansys-electronics-desktop-student)提供 Student 2025 R2，内置学习许可有效至 2027-07-31。官方规定三维体网格最多 64,000 个单元，并限制为本地求解。以下载时的官方版本、条款和网格限制为准。

本机 Python 版本为 3.12.14。复制整个技能目录，在目标电脑重建环境，不复制 `.venv`：

```powershell
py -3.12 -m venv E:/MaxwellAgent/.venv
& 'E:/MaxwellAgent/.venv/Scripts/python.exe' -m pip install `
  -r 'E:/MaxwellAgent/maxwell-automatic-wwj/requirements.txt'
```

路径可替换。安装或授权 Maxwell 与安装 skill 是两件事；本包不包含 Ansys 软件或许可。

## 可见桌面与 MCP

按 [接入说明](agent-setup.md)，先在 MCP 进程链外的独立本地终端运行 `scripts/prepare_desktop.py`。它启动或附着唯一可见 AEDT 桌面后断开 API，保留窗口；求解 MCP 再附着该已存在桌面。这样避免 MCP 会话清理时关闭在其进程链中新建的主窗口，不需要修改 SDK 或进程隔离。

首次启动若有目录选项等原生初始化弹窗，由用户手动确认；不能通过屏幕识别或输入模拟处理。多个窗口、安装身份不一致或附着失败时停止并说明实际问题。

## 中文计算机名的已知诊断

本机曾出现网格器写入 `C:/temp/maxwell_<中文名>_<PID>.pjt/initial.ngmesh`，求解器却尝试读取名字含 `???` 的目录，返回 `NAME INVALID`。这种情况下，即使小模型也会报 Student 网格读取/保存错误，不能直接等同于无许可证或网格超限。

用户授权后，本机备份并迁移 Ansys 设置、将计算机名改为 `WWJ-PC`，手动重启后恢复求解。仅改变子进程 `COMPUTERNAME` 或临时目录父路径没有解决该案例。

其他机器须先核对原生日志与路径；**本包不得自动改计算机名、重启、重置配置或修改许可**。必要系统改动应先说明证据、备份并取得该用户授权。

## 分发

仓库版只包含本单工况的脚本、技能与引用说明、依赖和配置。完整包只额外包含本案例通过验收的工程和匹配 `.aedtresults`，没有现成结果也可从头重新计算。

不要打包软件安装介质、许可配置、虚拟环境或完整系统抓包。运行输出保存在新的全 ASCII 绝对目录，方便独立核对与交付。
