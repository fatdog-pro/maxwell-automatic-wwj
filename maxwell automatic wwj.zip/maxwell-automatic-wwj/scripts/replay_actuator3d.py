"""Build and solve one 1 mm / 1 A / 200-turn 3D actuator in visible AEDT."""
from pathlib import Path
from contextlib import nullcontext
import argparse, os, sys, time, traceback, platform
from session_guard import SessionGuard
from workflow_common import write_json,need
from actuator3d_post import read_case,study_checks

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',required=True,type=Path)
    p.add_argument('--aedt-root',required=True,type=Path)
    p.add_argument('--version',default='2025.2')
    p.add_argument('--commercial',action='store_true')
    p.add_argument('--require-existing',action='store_true',help='Attach only; required by the stdio MCP launcher')
    a=p.parse_args()
    if not a.output.is_absolute() or not str(a.output).isascii():p.error('Use a new absolute ASCII output directory')
    out=a.output.resolve();out.mkdir(parents=True,exist_ok=False)
    root=a.aedt_root.resolve();student=not a.commercial
    s={'status':'running','kind':'actuator3d_single','case_count':1,'started':time.time(),'output':str(out),'cases':[],
       'solver_success':False,'physics_verified':False,'model_dimension':'full3D','geometry_symmetry':'axisymmetric'}
    def stage(value):
        s['stage']=value;write_json(out/'status.json',s);print(value,flush=True)
    guard=SessionGuard();d=None
    try:
        if not platform.node().isascii():raise RuntimeError('Non-ASCII hostname may corrupt native mesh paths; do not rename automatically')
        need((root/('ansysedtsv.exe' if student else 'ansysedt.exe')).is_file(),'Invalid AEDT root')
        tag=a.version.replace('20','',1).replace('.','')
        os.environ[('ANSYSEMSV_ROOT' if student else 'ANSYSEM_ROOT')+tag]=str(root)
        if student and a.version=='2025.2':os.environ['PYAEDT_USE_PRE_GRPC_ARGS']='True'
        from ansys.aedt.core import Desktop,Maxwell3d
        from ansys.aedt.core.generic.settings import settings
        from actuator3d_builder import build
        settings.enable_error_handler=False;settings.grpc_local=True;settings.grpc_listen_all=False
        if student and a.version=='2025.2':settings.grpc_secure_mode=False
        guard.acquire();pick=guard.choose(a.version,student,root)
        if a.require_existing and pick['new_desktop']:
            raise RuntimeError('MCP requires an existing visible AEDT. Run prepare_desktop.py from an independent local CLI first.')
        with nullcontext() if pick['new_desktop'] else guard.prohibit_new_launch():
            d=Desktop(version=a.version,student_version=student,non_graphical=False,close_on_exit=False,**pick)
        guard.check(d,'connected')
        if d.are_there_simulations_running:raise RuntimeError('An existing native simulation is running')
        pname='Actuator3D_'+out.name.replace('-','_')
        project=out/(pname+'.aedt')
        if pname in d.project_list:raise RuntimeError('Project already open')
        s.update(project=str(project),native_version=d.odesktop.GetVersion(),pid=d.aedt_process_id)
        cases=[('Nominal_1mm_1A',1.,1.,True)]
        for name,gap,current,fine in cases:
            stage(name+': geometry');caseout=out/name;caseout.mkdir()
            with guard.prohibit_new_launch():
                app=Maxwell3d(project=str(project),design=name,solution_type='Magnetostatic',
                    version=a.version,student_version=student,new_desktop=False,non_graphical=False,
                    close_on_exit=False,aedt_process_id=d.aedt_process_id,port=d.port)
            meta=build(app,caseout,gap_mm=gap,current_a=current,fine=fine)
            c={'design':name,'model':meta};s['cases'].append(c)
            need(app.save_project(),'Save geometry failed');guard.check(d,name+': mesh_solve');stage(name+': solve')
            started=time.time();solved=app.analyze_setup('Setup1',cores=1,tasks=1,use_auto_settings=False)
            c['solve_seconds']=time.time()-started
            c['messages']=list(d.odesktop.GetMessages(pname,name,0))
            need(solved,'Native solve returned false')
            if not any('Normal completion of simulation' in m for m in c['messages']):raise RuntimeError('Native normal completion missing')
            stage(name+': native_results');c['values']=read_case(app,caseout,meta)
            if student and c['values']['native_convergence']['tetrahedra']>64000:raise RuntimeError('Student mesh limit exceeded')
            c['solved']=True
            meta['solver_success']=True;write_json(caseout/'actuator3d-build.json',meta)
            need(app.save_project(),'Save result failed');guard.check(d,name+': results_saved')
            write_json(out/'partial_results.json',s['cases'])
        s['solver_success']=True
        if len(s['cases'])==1:
            s['study_acceptance']=study_checks(s['cases'])
            if not s['study_acceptance']['passed']:raise RuntimeError('Physical acceptance failed')
            stage('native_visuals')
            from actuator3d_visuals import create_visuals
            from actuator3d_post import export_summary
            need(app.set_active_design('Nominal_1mm_1A'),'Cannot activate nominal result')
            s['visuals']=create_visuals(app,out/'Visuals',s['cases'][0]['model'])
            need(app.save_project(),'Save plotted result failed')
            guard.check(d,'before_saved_reread');stage('saved_project_reread')
            need(app.close_project(name=pname,save=True),'Close saved project failed')
            with guard.prohibit_new_launch():
                app=Maxwell3d(project=str(project),design='Nominal_1mm_1A',version=a.version,
                    student_version=student,new_desktop=False,non_graphical=False,close_on_exit=False,
                    aedt_process_id=d.aedt_process_id,port=d.port)
            rd=out/'SavedReread';rd.mkdir()
            actual=read_case(app,rd,s['cases'][0]['model']);expected=s['cases'][0]['values']
            errs={'force_z':abs(actual['force_xyz_N']['z']/expected['force_xyz_N']['z']-1),
                  'inductance':abs(actual['physical_L_H']/expected['physical_L_H']-1)}
            s['saved_reread']={'passed':max(errs.values())<1e-10,'relative_differences':errs,'values':actual}
            need(s['saved_reread']['passed'],'Saved project results differ')
            need(project.with_suffix('.aedtresults').is_dir(),'Native results folder missing')
            need(app.design_list==['Nominal_1mm_1A'],'Expected exactly one native design')
            s['summary']=export_summary(out,s['cases'][0])
            app.odesign.SetActiveEditor('3D Modeler');app.modeler.fit_all()
            need(app.save_project(),'Final native save failed');guard.check(d,'saved_reread_passed')
            s['physics_verified']=True
        s['status']='finalizing'
    except Exception as exc:
        s.update(status='failed',error=str(exc),traceback=traceback.format_exc());print(traceback.format_exc(),flush=True)
    finally:
        if d:
            try:
                if s.get('project'):s['native_messages']=list(d.odesktop.GetMessages(Path(s['project']).stem,'',0))
                guard.check(d,'finished');d.release_desktop(False,False)
            except Exception as exc:s.update(status='failed',detach_error=str(exc))
        s['window_evidence']=guard.evidence();guard.release();s['elapsed_seconds']=time.time()-s['started']
        if s['status']=='finalizing':s.update(status='completed',stage='completed')
        write_json(out/'status.json',s)
    return 1 if s['status']=='failed' else 0

if __name__=='__main__':sys.exit(main())
