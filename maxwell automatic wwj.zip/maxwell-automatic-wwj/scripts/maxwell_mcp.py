#!/usr/bin/env python
"""Attach-only stdio MCP for one fixed 3D actuator operating point."""
from __future__ import annotations

import argparse
from pathlib import Path
from fastmcp import FastMCP
from inventory import add_arguments, collect_inventory
from actuator_jobs import start_job, read_job


def build_server(workspace: Path, aedt_root: Path | None = None,
                 version: str = '2025.2', student: bool = True) -> FastMCP:
    server = FastMCP('Maxwell automatic wwj', instructions=(
        '作者：抖音 萌猪过河。Use inventory to inspect the environment and attach_only_preflight. '
        'When the user requests the fixed single actuator case, call start_actuator3d once, '
        'then poll job_status with its returned job id until a terminal state. '
        'MCP can only attach to one existing compatible visible desktop with a discovered local gRPC port. '
        'If it is absent or incompatible, stop and prepare the desktop outside MCP. '
        'The start tool accepts no code, parameters, or alternate operating points. '
        'A started job is not successful physics: require native convergence, physics_verified, '
        'study_acceptance and saved_reread evidence. Retain the project and leave the native desktop visible.'
    ))

    @server.tool
    def inventory() -> dict:
        """Inspect files, window metadata and existing gRPC readiness without attaching or launching."""
        return collect_inventory(workspace, aedt_root, version, student)

    @server.tool
    def start_actuator3d() -> dict:
        """Run one fixed 3D actuator case in an existing compatible visible Maxwell desktop; return a job id."""
        return start_job(workspace, aedt_root, version, student)

    @server.tool
    def job_status(job_id: str) -> dict:
        """Read single-case progress, numerical checks, saved reread and retained native artifacts."""
        return read_job(workspace, job_id)

    return server


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    add_arguments(parser)
    args = parser.parse_args()
    build_server(args.workspace, args.aedt_root, args.version, args.student).run(transport='stdio')


if __name__ == '__main__':
    main()
