"""Small shared helpers for the single operating-point workflow."""
import json

def write_json(path,value):
    temp=path.with_suffix(path.suffix+'.tmp')
    temp.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    temp.replace(path)

def need(value,label):
    if value is False or value is None:raise RuntimeError(label)
    return value
