"""Prepare the single visible AEDT from an independent local CLI before MCP."""
from pathlib import Path
from contextlib import nullcontext
import argparse,json,os
from session_guard import SessionGuard

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--aedt-root',required=True,type=Path);p.add_argument('--version',default='2025.2')
    p.add_argument('--commercial',action='store_true');a=p.parse_args();student=not a.commercial
    root=a.aedt_root.resolve();exe=root/('ansysedtsv.exe' if student else 'ansysedt.exe')
    if not exe.is_file():raise ValueError('Invalid AEDT executable')
    tag=a.version.replace('20','',1).replace('.','')
    os.environ[('ANSYSEMSV_ROOT' if student else 'ANSYSEM_ROOT')+tag]=str(root)
    if student and a.version=='2025.2':os.environ['PYAEDT_USE_PRE_GRPC_ARGS']='True'
    from ansys.aedt.core import Desktop
    from ansys.aedt.core.generic.settings import settings
    settings.enable_error_handler=False;settings.grpc_local=True;settings.grpc_listen_all=False
    if student and a.version=='2025.2':settings.grpc_secure_mode=False
    g=SessionGuard();d=None;g.acquire()
    try:
        pick=g.choose(a.version,student,root)
        with nullcontext() if pick['new_desktop'] else g.prohibit_new_launch():
            d=Desktop(version=a.version,student_version=student,non_graphical=False,close_on_exit=False,**pick)
        info=g.check(d,'prepared_for_external_mcp');info.update(port=d.port,version=d.odesktop.GetVersion())
        print(json.dumps(info,ensure_ascii=False),flush=True)
    finally:
        if d:d.release_desktop(False,False)
        g.release()

if __name__=='__main__':main()
