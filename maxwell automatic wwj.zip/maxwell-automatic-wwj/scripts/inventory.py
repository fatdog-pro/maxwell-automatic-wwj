"""Read-only files, process metadata and official gRPC discovery; never attach or launch."""
from __future__ import annotations

import argparse
from contextlib import redirect_stdout
import importlib.metadata
import json
import os
from pathlib import Path
import re
import sys

from session_guard import SessionGuard

JOB_KIND = 'actuator3d_single'
EXPECTED_CASE_COUNT = 1
RUNNER_NAME = 'replay_actuator3d.py'


def _discover_grpc(version, student):
    # Keep any import/discovery diagnostics away from the stdio MCP channel.
    # active_sessions only discovers existing native processes and their ports.
    with redirect_stdout(sys.stderr):
        from ansys.aedt.core.generic.general_methods import active_sessions
        return active_sessions(version=version, student_version=student, non_graphical=False)


def existing_desktop_preflight(sessions, aedt_root, version, student, inspection_error=None):
    """Fail closed unless one compatible restored GUI already has a discoverable gRPC port."""
    result = {'ready': False, 'policy': 'attach_existing_only', 'session': None}
    try:
        if inspection_error:
            raise RuntimeError(inspection_error)
        if aedt_root is None:
            raise RuntimeError('Configure --aedt-root before checking attachment')
        if len(sessions) != 1:
            raise RuntimeError('Exactly one existing AEDT process is required; prepare the visible desktop outside MCP')
        item = sessions[0]
        windows = item.get('windows', [])
        if len(windows) != 1 or windows[0].get('minimized') is not False:
            raise RuntimeError('Existing AEDT must have exactly one visible, non-minimized main window')
        expected_name = 'ansysedtsv.exe' if student else 'ansysedt.exe'
        expected_exe = (Path(aedt_root).expanduser().resolve() / expected_name).resolve()
        if item.get('name', '').lower() != expected_name:
            raise RuntimeError('The existing AEDT edition differs from the configured edition')
        if not item.get('exe') or Path(item['exe']).resolve() != expected_exe:
            raise RuntimeError('Existing AEDT executable differs from the configured installation path')
        if any(str(arg).lower() in ('-ng', '-batchsolve', '-batchextract') for arg in item.get('command_line', [])):
            raise RuntimeError('An existing background/batch AEDT session cannot be used')
        pid, created_at = item.get('pid'), item.get('created_at')
        if type(pid) is not int or pid <= 0 or not isinstance(created_at, (int, float)) or created_at <= 0:
            raise RuntimeError('Existing AEDT process identity is incomplete')
        port = _discover_grpc(version, student).get(pid)
        if type(port) is not int or not 0 < port < 65536:
            raise RuntimeError('No existing local gRPC port matches the requested AEDT version and edition')
        result.update(ready=True, reason=None, session={
            'pid': pid, 'created_at': created_at, 'port': port, 'exe': str(expected_exe),
            'version': version, 'student': student, 'new_desktop': False,
        })
    except Exception as exc:
        result['reason'] = str(exc)
    return result


def collect_inventory(workspace: Path, aedt_root: Path | None = None,
                      version: str = '2025.2', student: bool = True) -> dict:
    packages = {}
    for name in ('pyaedt', 'fastmcp', 'mcp', 'psutil'):
        try:
            packages[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            packages[name] = None
    root = Path(aedt_root).expanduser().resolve() if aedt_root else None
    roots = [{'source': '--aedt-root', 'root': str(root)}] if root else []
    for key, value in os.environ.items():
        if re.fullmatch(r'ANSYSEM(?:SV)?_ROOT\d{3}', key):
            roots.append({'source': key, 'root': value})
    for item in roots:
        location = Path(item['root'])
        item['commercial_executable_exists'] = (location / 'ansysedt.exe').is_file()
        item['student_executable_exists'] = (location / 'ansysedtsv.exe').is_file()
    executable = root / ('ansysedtsv.exe' if student else 'ansysedt.exe') if root else None
    try:
        sessions = SessionGuard.inventory() if os.name == 'nt' else []
        inspection_error = None if os.name == 'nt' else 'Visible session guard requires Windows'
    except Exception as exc:
        sessions, inspection_error = [], str(exc)
    preflight = existing_desktop_preflight(sessions, root, version, student, inspection_error)
    single = (inspection_error is None and len(sessions) == 1
              and len(sessions[0].get('windows', [])) == 1
              and sessions[0]['windows'][0].get('minimized') is False)
    return {
        'skill_name': 'Maxwell automatic wwj', 'author': '作者：抖音 萌猪过河',
        'python': sys.version.split()[0], 'python_executable': sys.executable,
        'packages': packages, 'requested_version': version, 'student': student,
        'aedt_roots': roots, 'configured_executable': str(executable) if executable else None,
        'configured_executable_exists': executable.is_file() if executable else None,
        'workspace': str(Path(workspace).expanduser().resolve()),
        'aedt_sessions': sessions, 'session_inspection_error': inspection_error,
        'one_restored_visible_main_window_observed': single,
        'attach_only_preflight': preflight,
        'capabilities': ['read_only_environment_inventory', 'visible_actuator3d_single_replay'],
        'accepted_examples': [JOB_KIND],
        'fixed_studies': {JOB_KIND: {'expected_case_count': EXPECTED_CASE_COUNT,
                                  'runner_present': Path(__file__).with_name(RUNNER_NAME).is_file()}},
        'simulation_status': 'fresh_single_case_solve_and_acceptance_required_for_each_job',
        'solver_started': False, 'solver_success': False, 'physics_verified': False,
        'license_status': 'not_checked_by_inventory',
        'native_connection_status': 'not_attempted_by_inventory',
        'native_session_policy': 'MCP attaches only to one existing compatible visible AEDT; desktop preparation occurs outside MCP',
        'qualification': 'Read-only gRPC discovery does not prove a native connection, solver license, or solved physics.',
    }


def add_arguments(parser):
    parser.add_argument('--workspace', type=Path, required=True)
    parser.add_argument('--aedt-root', type=Path)
    parser.add_argument('--version', default='2025.2')
    edition = parser.add_mutually_exclusive_group()
    edition.add_argument('--student', dest='student', action='store_true')
    edition.add_argument('--commercial', dest='student', action='store_false')
    parser.set_defaults(student=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    add_arguments(parser)
    args = parser.parse_args()
    print(json.dumps(collect_inventory(args.workspace, args.aedt_root, args.version, args.student),
                     ensure_ascii=False, indent=2, allow_nan=False))
    return 0


if __name__ == '__main__':
    sys.exit(main())
