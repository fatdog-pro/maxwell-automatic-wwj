"""Official-API native displays for an already-solved 3D actuator.

No desktop launch/connection, screen capture, image recognition, or simulated
input occurs here. All pictures come from AEDT ExportModelImageToFile.
"""
from __future__ import annotations

import json
import uuid
from pathlib import Path


def _need(value, operation):
    if value is False or value is None:
        raise RuntimeError("Native actuator display failed: " + operation)
    return value


def _image(app, path, objects, plot=None, orientation="isometric"):
    if path.exists():
        raise FileExistsError("Refusing to overwrite an earlier render: " + str(path))
    _need(app.post.export_model_picture(
        full_name=str(path), orientation=orientation, width=1600, height=1200,
        show_axis=True, show_grid=False, show_ruler=True, show_region=False,
        selections=objects, field_selections=plot or [],
    ), "export " + path.name)
    if not path.is_file() or path.stat().st_size < 256:
        raise RuntimeError("Native image output is missing or empty: " + str(path))
    with path.open("rb") as stream:
        signature = stream.read(8)
    if signature != b"\x89PNG\r\n\x1a\n":
        raise RuntimeError("Native renderer did not write actual PNG bytes: " + str(path))
    return {"path": str(path), "bytes": path.stat().st_size, "format": "PNG",
            "native_api": "ExportModelImageToFile", "orientation": orientation,
            "field_plot": plot, "objects": list(objects)}


def create_visuals(app, out, meta):
    """Render geometry, native mesh, B-vector, 3D B surface, and XZ B section.

    The caller must supply its solved Maxwell3d Magnetostatic app and metadata
    from actuator3d_builder.build(). It owns desktop lifetime and saving.
    Required geometry/B magnitude failures raise and retain a partial manifest.
    Optional mesh/vector failures are explicitly reported in ``errors`` and
    never presented as successful artifacts. Only plots made here are deleted.
    The final native XZ Mag_B plot stays visible in the original design.
    """
    if not app.is3d or app.solution_type != "Magnetostatic":
        raise ValueError("An already solved Maxwell 3D Magnetostatic design is required")
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    manifest = out / "actuator3d-visuals.json"
    if manifest.exists():
        raise FileExistsError("Use a fresh display directory: " + str(manifest))
    prefix = "WWJ3D_" + uuid.uuid4().hex[:8]
    solution = meta["solution"]
    core = list(meta["core_objects"])
    armature = meta["armature_object"]
    coil = meta["coil_object"]
    gaps = list(meta["gap_objects"])
    solids = core + [armature, coil]
    section_objects = solids + gaps
    missing = [name for name in section_objects + [meta["region_object"]]
               if name not in app.modeler.object_names]
    if missing:
        raise ValueError("Native model objects missing: " + repr(missing))
    result = {"status": "running", "native_images": {}, "errors": [],
              "final_native_plot": None, "cutplane": "Global:XZ",
              "section_scope": "Actual core, armature, coil and both working air gaps; exterior air omitted from this display.",
              "static_result": True, "model_geometry_changed": False,
              "native_solution": solution}

    def write_manifest():
        manifest.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")

    def transparency(core_value, armature_value, coil_value):
        for name in core:
            app.modeler[name].transparency = core_value
        app.modeler[armature].transparency = armature_value
        app.modeler[coil].transparency = coil_value

    def remove_owned(plot):
        if plot is not None:
            _need(app.post.delete_field_plot(plot.name), "remove temporary overlay " + plot.name)

    try:
        app.odesktop.RestoreWindow()
        app.odesign.SetActiveEditor("3D Modeler")
        app.modeler[meta["region_object"]].transparency = 1.0
        for name in gaps:
            app.modeler[name].transparency = 0.9
        transparency(0.6, 0.35, 0.0)
        result["native_images"]["geometry"] = _image(
            app, out / "Actuator3D_Geometry.png", solids)

        # PyAEDT's own export_mesh_obj uses a surface field plot named Mesh;
        # it displays the real solved tetrahedral mesh's surface triangulation.
        mesh = None
        try:
            transparency(0.2, 0.15, 0.0)
            mesh = _need(app.post.create_fieldplot_surface(
                section_objects, "Mesh", setup=solution,
                plot_name=prefix + "_Mesh", field_type="Fields"), "native mesh plot")
            result["native_images"]["mesh"] = _image(
                app, out / "Actuator3D_SurfaceMesh.png", section_objects, mesh.name)
        except Exception as exc:
            result["errors"].append({"stage": "optional_native_surface_mesh", "error": str(exc)})
        finally:
            remove_owned(mesh)

        # Use built-in cut plane instead of creating/changing solved geometry.
        vector = None
        try:
            transparency(0.85, 0.85, 0.85)
            vector = _need(app.post.create_fieldplot_cutplane(
                ["Global:XZ"], "B_Vector", setup=solution,
                plot_name=prefix + "_BVectorXZ", filter_objects=section_objects,
                field_type="Fields"), "XZ magnetic flux vectors")
            vector.ArrowUniform = True
            vector.ArrowSpacing = 0.7
            _need(vector.update_field_plot_settings(), "vector display settings")
            result["native_images"]["vector_xz"] = _image(
                app, out / "Actuator3D_BVector_XZ.png", section_objects,
                vector.name, orientation="front")
        except Exception as exc:
            result["errors"].append({"stage": "optional_native_B_vector_XZ", "error": str(exc)})
        finally:
            remove_owned(vector)

        surface = _need(app.post.create_fieldplot_surface(
            core + [armature], "Mag_B", setup=solution,
            plot_name=prefix + "_MagB_Surface", field_type="Fields"), "3D Mag_B surface")
        try:
            transparency(0.0, 0.0, 0.0)
            surface.Filled = True
            surface.MapTransparency = False
            _need(surface.update_field_plot_settings(), "3D magnitude display settings")
            result["native_images"]["magnitude_3d"] = _image(
                app, out / "Actuator3D_MagB_Surface.png", solids, surface.name)
        finally:
            remove_owned(surface)

        # Leave one clear native scalar plot rather than several overlapping
        # mesh, vector and scalar overlays. No original/user plots are removed.
        transparency(0.8, 0.8, 0.8)
        magnitude = _need(app.post.create_fieldplot_cutplane(
            ["Global:XZ"], "Mag_B", setup=solution,
            plot_name=prefix + "_MagB_XZ", filter_objects=section_objects,
            field_type="Fields"), "XZ Mag_B section")
        magnitude.Filled = True
        magnitude.MapTransparency = False
        _need(magnitude.update_field_plot_settings(), "XZ magnitude display settings")
        result["native_images"]["magnitude_xz"] = _image(
            app, out / "Actuator3D_MagB_XZ.png", section_objects,
            magnitude.name, orientation="front")
        result["native_images"]["magnitude_xz_isometric"] = _image(
            app, out / "Actuator3D_MagB_XZ_Isometric.png", section_objects,
            magnitude.name, orientation="isometric")
        result["final_native_plot"] = magnitude.name
        result["status"] = "required_outputs_complete" if result["errors"] else "complete"
        app.odesign.SetActiveEditor("3D Modeler")
        app.modeler.fit_all()
        app.odesktop.RestoreWindow()
        write_manifest()
        return result
    except Exception as exc:
        result["status"] = "failed"
        result["fatal_error"] = {"type": type(exc).__name__, "message": str(exc)}
        write_manifest()
        raise
