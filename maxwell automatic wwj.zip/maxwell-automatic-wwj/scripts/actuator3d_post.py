"""Read native 3-D actuator results; analytical values are never solver data."""
import csv, json, math, re
from pathlib import Path

def need(value,label):
    if value is None or value is False:raise RuntimeError(label)
    return value

def scalar(app,expression):
    data=need(app.post.get_solution_data(expressions=expression,setup_sweep_name='Setup1 : LastAdaptive',
                                       report_category='Magnetostatic'),'Missing native report '+expression)
    _,vals=data.get_expression_data(expression,formula='real',convert_to_SI=True)
    numbers=[float(x) for x in vals.flat]
    if len(numbers)!=1 or not math.isfinite(numbers[0]):raise RuntimeError('Expected one finite result for '+expression)
    unit=data.units_data.get(expression)
    if '.Force_' in expression and unit not in ('N','newton','mN','uN','kN'):raise RuntimeError('Unknown force unit '+str(unit))
    if '.L(' in expression and unit not in ('H','mH','uH','nH','pH'):raise RuntimeError('Unknown inductance unit '+str(unit))
    return numbers[0],data.units_data.get(expression)

def convergence(out):
    raw=(out/'convergence.txt').read_text(encoding='utf-8-sig')
    if 'Tetrahedra' not in raw or 'Total Energy (J)' not in raw:raise RuntimeError('Expected native 3D tetrahedral/Joule convergence table')
    rows=[]
    for line in raw.splitlines():
        if re.match(r'^\s*\d+\|',line):rows.append([x.strip() for x in line.split('|') if x.strip()])
    if not rows:raise RuntimeError('Native adaptive passes missing')
    v=rows[-1]
    result={'passes':int(v[0]),'tetrahedra':int(v[1]),'total_energy_J':float(v[2]),
            'energy_error_percent':float(v[3]),'delta_energy_percent':float(v[4])}
    target=re.search(r'Target\s*:\s*\(([^,]+),\s*([^\)]+)\)',raw)
    result['target_percent']=[float(target[1]),float(target[2])]
    mesh=(out/'mesh.txt').read_text(encoding='utf-8-sig')
    count=int(need(re.search(r'Total number of mesh elements:\s*(\d+)',mesh),'Missing mesh size')[1])
    if count!=result['tetrahedra']:raise RuntimeError('Native mesh/convergence counts differ')
    result['converged']=result['passes']>=2 and result['energy_error_percent']<=result['target_percent'][0] and abs(result['delta_energy_percent'])<=result['target_percent'][1]
    return result

def read_case(app,out,meta):
    out=Path(out)
    need(app.export_convergence('Setup1',output_file=str(out/'convergence.txt')),'Convergence export failed')
    need(app.export_mesh_stats('Setup1',output_file=str(out/'mesh.txt')),'Mesh export failed')
    native=convergence(out)
    force={}; units={}
    for axis in 'xyz':
        force[axis],units[axis]=scalar(app,meta['force_name']+'.Force_'+axis)
    expression=meta['matrix_name']+'.L('+meta['source_name']+','+meta['source_name']+')'
    one_turn_l,lunit=scalar(app,expression)
    if one_turn_l<=0 or force['z']>=0:raise RuntimeError('Expected positive inductance and downward attraction')
    # Matrix is deliberately assigned one turn; excitation is total N*I.
    physical_l=one_turn_l*meta['turns']**2
    coenergy=.5*physical_l*meta['physical_current_A']**2
    record={'gap_mm':meta['gap_mm'],'physical_current_A':meta['physical_current_A'],'turns':meta['turns'],
            'force_xyz_N':force,'one_turn_L_H':one_turn_l,'physical_L_H':physical_l,
            'coenergy_from_L_J':coenergy,'native_convergence':native,
            'matrix_native_energy_relative_difference':abs(coenergy/native['total_energy_J']-1),
            'transverse_force_relative':math.hypot(force['x'],force['y'])/abs(force['z']),
            'native_report_units':{'force':units,'inductance':lunit},
            'inductance_expression':expression}
    (out/'native-values.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
    return record

def study_checks(cases):
    if len(cases)!=1:raise RuntimeError('Expected exactly one solved case')
    v=cases[0]['values']
    checks={
      'one_native_3d_solution':len(cases)==1,
      'fixed_operating_point':v['gap_mm']==1 and v['physical_current_A']==1 and v['turns']==200,
      'native_convergence':v['native_convergence']['converged'],
      'force_toward_closing_gap':v['force_xyz_N']['z']<0,
      'positive_inductance':v['physical_L_H']>0,
      'energy_matrix_agreement_1pct':v['matrix_native_energy_relative_difference']<.01,
      'axisymmetry_transverse_force_5pct':v['transverse_force_relative']<.05}
    return {'passed':all(checks.values()),'checks':checks}

def export_summary(out,case):
    """Write one row of actual native results and a compact human-readable report."""
    out=Path(out);v=case['values'];n=v['native_convergence']
    row={'case':case['design'],'gap_mm':v['gap_mm'],'current_A':v['physical_current_A'],'turns':v['turns'],
         'attraction_N':-v['force_xyz_N']['z'],'inductance_mH':1000*v['physical_L_H'],
         'energy_mJ':1000*v['coenergy_from_L_J'],'tetrahedra':n['tetrahedra'],
         'passes':n['passes'],'energy_error_percent':n['energy_error_percent']}
    csvpath=out/'ResultSummary.csv'
    with csvpath.open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=list(row));w.writeheader();w.writerow(row)
    report=out/'ResultSummary.md'
    text='# Maxwell 3D: single operating point\n\n| Quantity | Native result |\n|---|---:|\n'
    text+='\n'.join(f'| {key} | {value} |' for key,value in row.items())
    text+='\n\nLinear magnetostatic teaching model. Native fields are in Visuals/.\n'
    report.write_text(text,encoding='utf-8')
    return {'csv':str(csvpath),'report':str(report),'source':'Native 3D virtual force and inductance matrix'}
