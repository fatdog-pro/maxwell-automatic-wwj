"""Keep one visible local AEDT desktop across CLI and MCP helper processes.

No screen capture, OCR, input injection, window clicking, or project closing is
used. Win32 calls only enumerate window metadata and hold a session-wide mutex.
AEDT's official RestoreWindow API restores the selected native desktop.
"""
from __future__ import annotations

from contextlib import contextmanager
import ctypes
from ctypes import wintypes
import importlib
import os
from pathlib import Path
import time
from unittest.mock import patch


class SessionPolicyError(RuntimeError):
    pass


class SessionGuard:
    MUTEX_NAME = r"Local\MaxwellAutomaticWWJ.VisibleAedt.Session.v1"

    def __init__(self):
        self.handle = None
        self.pid = None
        self.created_at = None
        self.snapshots = []
        self.mode = None

    def acquire(self):
        if os.name != "nt":
            raise SessionPolicyError("The visible single-window guard currently requires Windows.")
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel.CreateMutexW.argtypes = (ctypes.c_void_p, wintypes.BOOL, wintypes.LPCWSTR)
        kernel.CreateMutexW.restype = wintypes.HANDLE
        kernel.WaitForSingleObject.argtypes = (wintypes.HANDLE, wintypes.DWORD)
        kernel.WaitForSingleObject.restype = wintypes.DWORD
        kernel.ReleaseMutex.argtypes = (wintypes.HANDLE,)
        kernel.ReleaseMutex.restype = wintypes.BOOL
        kernel.CloseHandle.argtypes = (wintypes.HANDLE,)
        kernel.CloseHandle.restype = wintypes.BOOL
        handle = kernel.CreateMutexW(None, False, self.MUTEX_NAME)
        if not handle:
            raise ctypes.WinError(ctypes.get_last_error())
        result = kernel.WaitForSingleObject(handle, 0)
        if result not in (0, 0x80):  # acquired or abandoned by an exited helper
            kernel.CloseHandle(handle)
            raise SessionPolicyError("Another Maxwell helper owns the visible desktop. Inspect that job; do not launch again.")
        self.kernel, self.handle = kernel, handle

    def release(self):
        if self.handle:
            self.kernel.ReleaseMutex(self.handle)
            self.kernel.CloseHandle(self.handle)
            self.handle = None

    @staticmethod
    def inventory():
        """Read process identity and visible, unowned main-window handles only."""
        import psutil
        processes = []
        for process in psutil.process_iter(["pid", "name"]):
            if (process.info.get("name") or "").lower() not in ("ansysedt.exe", "ansysedtsv.exe"):
                continue
            try:
                processes.append({"pid": process.pid, "name": process.name(),
                                  "exe": process.exe(), "created_at": process.create_time(),
                                  "command_line": process.cmdline(), "windows": []})
            except psutil.NoSuchProcess:
                continue
            except psutil.AccessDenied as exc:
                raise SessionPolicyError(f"Cannot inspect existing AEDT PID {process.pid}; refusing another desktop.") from exc
        if not processes:
            return processes
        user = ctypes.WinDLL("user32", use_last_error=True)
        callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        user.EnumWindows.argtypes = (callback_type, wintypes.LPARAM)
        user.EnumWindows.restype = wintypes.BOOL
        user.GetWindowThreadProcessId.argtypes = (wintypes.HWND, ctypes.POINTER(wintypes.DWORD))
        user.GetWindowThreadProcessId.restype = wintypes.DWORD
        user.IsWindowVisible.argtypes = (wintypes.HWND,)
        user.IsWindowVisible.restype = wintypes.BOOL
        user.IsIconic.argtypes = (wintypes.HWND,)
        user.IsIconic.restype = wintypes.BOOL
        user.GetWindow.argtypes = (wintypes.HWND, wintypes.UINT)
        user.GetWindow.restype = wintypes.HWND
        user.GetWindowTextLengthW.argtypes = (wintypes.HWND,)
        user.GetWindowTextLengthW.restype = ctypes.c_int
        user.GetWindowTextW.argtypes = (wintypes.HWND, wintypes.LPWSTR, ctypes.c_int)
        user.GetWindowTextW.restype = ctypes.c_int
        by_pid = {row["pid"]: row for row in processes}

        @callback_type
        def collect(hwnd, _):
            pid = wintypes.DWORD()
            user.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            if pid.value in by_pid and user.IsWindowVisible(hwnd) and not user.GetWindow(hwnd, 4):
                length = user.GetWindowTextLengthW(hwnd)
                if length:
                    title = ctypes.create_unicode_buffer(length + 1)
                    user.GetWindowTextW(hwnd, title, len(title))
                    by_pid[pid.value]["windows"].append({"handle": int(hwnd), "title": title.value,
                                                       "minimized": bool(user.IsIconic(hwnd))})
            return True

        if not user.EnumWindows(collect, 0):
            raise ctypes.WinError(ctypes.get_last_error())
        return processes

    def choose(self, version, student, expected_root=None):
        if not self.handle:
            raise SessionPolicyError("Acquire the shared desktop lock before inspecting or connecting.")
        inventory = self.inventory()
        self.snapshots.append({"stage": "before_connect", "time": time.time(), "processes": inventory})
        if len(inventory) > 1:
            raise SessionPolicyError("Multiple AEDT processes already exist. No session was closed or launched.")
        if not inventory:
            self.mode = "new-visible-desktop"
            return {"new_desktop": True}
        item = inventory[0]
        if len(item["windows"]) != 1:
            raise SessionPolicyError("Existing AEDT does not expose exactly one visible main window; refusing a new desktop.")
        expected_name = "ansysedtsv.exe" if student else "ansysedt.exe"
        if item["name"].lower() != expected_name:
            raise SessionPolicyError("The existing AEDT edition differs from this run; no second desktop will be opened.")
        if expected_root and Path(item["exe"]).resolve() != (Path(expected_root)/expected_name).resolve():
            raise SessionPolicyError("Existing AEDT executable differs from --aedt-root; refusing attachment.")
        if any(arg.lower() in ("-ng", "-batchsolve", "-batchextract") for arg in item["command_line"]):
            raise SessionPolicyError("Existing AEDT is a background/batch session; refusing attachment.")
        # Use the installed official discovery implementation for version/edition/port matching.
        from ansys.aedt.core.generic.general_methods import active_sessions
        sessions = active_sessions(version=version, student_version=student, non_graphical=False)
        port = sessions.get(item["pid"], -1)
        if not isinstance(port, int) or port <= 0:
            raise SessionPolicyError("The existing visible AEDT has no verified matching local gRPC session; no second window was opened.")
        self.pid, self.created_at = item["pid"], item["created_at"]
        self.mode = "attach-existing-visible-desktop"
        return {"new_desktop": False, "aedt_process_id": self.pid, "port": port}

    @contextmanager
    def prohibit_new_launch(self):
        """Fail closed if PyAEDT's attach path tries to launch after a stale port.

        The installed PyAEDT 1.8.0 _validate_port may switch new_desktop=True.
        Restrict its launcher for this constructor call only; never alter AEDT.
        """
        desktop_module = importlib.import_module("ansys.aedt.core.desktop")
        with patch.object(desktop_module, "launch_aedt", side_effect=SessionPolicyError(
                "Existing AEDT attachment failed; launching a replacement/second desktop is forbidden.")):
            yield

    def check(self, desktop, stage, restore=True):
        pid = int(desktop.aedt_process_id)
        if self.pid is not None and pid != self.pid:
            raise SessionPolicyError("AEDT PID changed unexpectedly; stopping this helper.")
        if bool(desktop.odesktop.GetIsNonGraphical()):
            raise SessionPolicyError("AEDT reports non-graphical mode; visible operation is required.")
        if restore:
            desktop.odesktop.RestoreWindow()
        records = self.inventory()
        self.snapshots.append({"stage": stage, "time": time.time(), "processes": records})
        if len(records) != 1 or records[0]["pid"] != pid:
            raise SessionPolicyError("Exactly one matching AEDT process is required; no process was closed.")
        row = records[0]
        if self.created_at is not None and row["created_at"] != self.created_at:
            raise SessionPolicyError("AEDT PID was reused by another process; refusing further work.")
        if len(row["windows"]) != 1 or row["windows"][0]["minimized"]:
            raise SessionPolicyError("Expected one visible, restored AEDT main window.")
        self.pid, self.created_at = pid, row["created_at"]
        return {"mode": self.mode, "pid": pid, "visible_main_windows": 1,
                "window": row["windows"][0], "stage": stage}

    def evidence(self):
        return {"policy": "one-visible-local-AEDT-main-window; official-API-only; detach-on-exit",
                "mode": self.mode, "pid": self.pid, "snapshots": self.snapshots,
                "scope": "Checked at native workflow stage boundaries; does not prevent a user minimizing or launching another app externally."}
