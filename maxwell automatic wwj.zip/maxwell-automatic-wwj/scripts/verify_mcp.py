"""Verify real stdio discovery and read-only inventory; never request a solve."""
from __future__ import annotations

import argparse
import asyncio
import json
import os
from pathlib import Path
import sys
import time
from fastmcp import Client
from fastmcp.client.transports import StdioTransport
from inventory import add_arguments, JOB_KIND, EXPECTED_CASE_COUNT


def payload(result):
    if isinstance(result.data, dict):
        return result.data
    for item in result.content:
        if getattr(item, 'type', None) == 'text':
            value = json.loads(item.text)
            if isinstance(value, dict):
                return value
    raise RuntimeError('Expected structured JSON from MCP tool')


async def verify(args):
    bridge = Path(__file__).resolve().with_name('maxwell_mcp.py')
    command = ['-B', '-u', str(bridge), '--workspace', str(args.workspace.resolve()),
               '--version', args.version, '--student' if args.student else '--commercial']
    if args.aedt_root:
        command.extend(['--aedt-root', str(args.aedt_root.resolve())])
    transport = StdioTransport(sys.executable, command, env=dict(os.environ, PYTHONUTF8='1', PYTHONIOENCODING='utf-8'))
    record = {'started_unix': time.time(), 'transport': 'stdio', 'solver_requested': False,
              'solver_success': False, 'physics_verified': False}
    async with Client(transport, timeout=30, init_timeout=30) as client:
        discovered = await client.list_tools()
        names = sorted(tool.name for tool in discovered)
        if names != ['inventory', 'job_status', 'start_actuator3d']:
            raise RuntimeError(f'Unexpected MCP tools: {names}')
        schemas = {}
        for tool in discovered:
            schema = getattr(tool, 'input_schema', None)
            if schema is None:
                schema = tool.inputSchema
            schemas[tool.name] = schema
            expected = {'job_id'} if tool.name == 'job_status' else set()
            if (set(schema.get('properties', {})) != expected
                    or set(schema.get('required', [])) != expected
                    or schema.get('additionalProperties') is not False):
                raise RuntimeError(f'Unexpected input schema for {tool.name}: {schema}')
        inv = payload(await client.call_tool('inventory'))
        if inv.get('accepted_examples') != [JOB_KIND] or inv.get('solver_started') is not False:
            raise RuntimeError('Inventory returned inconsistent capabilities or started a solver')
        fixed = inv.get('fixed_studies', {})
        if set(fixed) != {JOB_KIND} or fixed[JOB_KIND].get('expected_case_count') != EXPECTED_CASE_COUNT:
            raise RuntimeError('Inventory must expose exactly one fixed actuator case')
        if inv.get('attach_only_preflight', {}).get('policy') != 'attach_existing_only':
            raise RuntimeError('MCP must require an already existing desktop')
        record.update(protocol_verified=True, tools=names, input_schemas=schemas, inventory=inv)
    args.record.parent.mkdir(parents=True, exist_ok=True)
    args.record.write_text(json.dumps(record, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')
    print(json.dumps(record, ensure_ascii=False, indent=2, allow_nan=False))
    return 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    add_arguments(parser)
    parser.add_argument('--record', required=True, type=Path)
    return asyncio.run(verify(parser.parse_args()))


if __name__ == '__main__':
    sys.exit(main())
