"""Build-only full 360-degree Maxwell 3D pot-core actuator.

Official PyAEDT 1.8 APIs only. The owning runner supplies a new Magnetostatic
design in its existing visible desktop and owns solve/result verification.
"""
from __future__ import annotations

import json
import math
from pathlib import Path

SPEC = {"dimension": 3, "solution_type": "Magnetostatic", "title": "PotCoreActuator3D"}


def need(value, label):
    if value is False or value is None:
        raise RuntimeError("Native operation failed: " + label)
    return value


def magnetic_circuit_reference(gap_mm=1.0, current_a=1.0, turns=200):
    """Rough independent circuit estimate; ignores leakage and gap fringing."""
    mu0 = 4 * math.pi * 1e-7
    mu = 1000 * mu0
    pole_area = math.pi * 0.010**2
    return_area = math.pi * (0.030**2 - 0.025**2)
    gap_slope = (1 / pole_area + 1 / return_area) / mu0
    core_reluctance = 0.0325 / (mu * pole_area) + 0.0325 / (mu * return_area)
    core_reluctance += 2 * math.log(0.025 / 0.010) / (2 * math.pi * mu * 0.005)
    reluctance = gap_slope * gap_mm * 1e-3 + core_reluctance
    flux = turns * current_a / reluctance
    return {
        "reference_only": True,
        "leakage_and_fringing_neglected": True,
        "reluctance_A_per_Wb": reluctance,
        "pole_flux_Wb": flux,
        "central_gap_B_T": flux / pole_area,
        "physical_inductance_H": turns**2 / reluctance,
        "energy_J": (turns * current_a)**2 / (2 * reluctance),
        "attraction_force_magnitude_N": 0.5 * flux**2 * gap_slope,
    }


def build(app, out, gap_mm=1.0, current_a=1.0, fine=False):
    """Create one full 3D operating point; does not connect, launch, or solve.

    A closed annular stranded conductor is excited on a single generated radial
    cross-section by net ampere-turns. Matrix turns=1 deliberately describes
    that source: physical winding inductance is N^2 times native matrix L1.
    """
    from ansys.aedt.core.modules.boundary.maxwell_boundary import MatrixMagnetostatic, SourceMagnetostatic

    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    if not app.is3d or app.solution_type != "Magnetostatic":
        raise ValueError("A Maxwell 3D Magnetostatic design is required")
    if app.modeler.object_names:
        raise ValueError("Refusing to modify a populated design")
    gap_mm, current_a = float(gap_mm), float(current_a)
    if not (0.3 <= gap_mm <= 5) or not (0 < current_a <= 2):
        raise ValueError("Teaching range: gap 0.3..5 mm, current >0..2 A")

    turns = 200
    m = app.modeler
    m.model_units = "mm"
    app["gap"] = f"{gap_mm:.12g}mm"
    app["Icoil"] = f"{current_a:.12g}A"
    app["NI"] = "200*Icoil"
    steel = need(app.materials.add_material("WWJ_LinearCore_mu1000"), "core material")
    steel.permeability = 1000
    steel.conductivity = 0

    def cylinder(name, radius, z, height, material):
        return need(m.create_cylinder("Z", [0, 0, z], radius, height,
                                     name=name, material=material), name)

    core = cylinder("PotCore", 30, 0, 35, steel.name)
    cavity = cylinder("CoreCavityTool", 25, 5, 30, "vacuum")
    need(m.subtract(core.name, cavity.name, keep_originals=False), "hollow pot core")
    pole = cylinder("CentralPole", 10, 5, 30, steel.name)
    need(m.unite([core.name, pole.name]), "unite central pole and return yoke")
    core = m["PotCore"]
    core.solve_inside = True
    core.color = (110, 140, 163)
    core.transparency = 0.45

    armature = cylinder("Armature", 30, "35mm+gap", 5, steel.name)
    armature.solve_inside = True
    armature.color = (160, 180, 205)
    armature.transparency = 0.2

    coil = cylinder("Coil", 22, 7, 23, "copper")
    bore = cylinder("CoilBoreTool", 12, 7, 23, "vacuum")
    need(m.subtract(coil.name, bore.name, keep_originals=False), "annular conductor")
    coil.solve_inside = True
    coil.color = (218, 126, 38)

    # A section through the complete ring contains two disconnected rectangles.
    # Retain only its +X half so the source crosses the closed winding once.
    before = set(m.object_names)
    need(m.section(coil.name, "ZX", create_new=True), "radial coil section")
    created = [name for name in m.object_names if name not in before]
    if len(created) != 1:
        raise RuntimeError(f"Expected one compound coil section, obtained {created}")
    sections = need(m.separate_bodies(created[0]), "separate coil terminals")
    if len(sections) != 2:
        raise RuntimeError("The closed-ring section must produce exactly two terminals")
    sections = sorted(sections, key=lambda obj: float(obj.faces[0].center[0]))
    terminal = sections[-1]
    if len(terminal.faces) != 1 or float(terminal.faces[0].center[0]) <= 0:
        raise RuntimeError("Cannot identify positive-X coil terminal")
    if abs(float(terminal.faces[0].area) - 230.0) > 0.01:
        raise RuntimeError("Coil terminal does not span the full 10 x 23 mm section")
    need(m.delete(sections[0].name), "remove unused negative-X terminal")
    terminal.name = "CoilTerminal"
    need(app.assign_current(terminal.name, amplitude="NI", solid=False,
                            name="CoilAT"), "stranded net ampere-turn source")
    need(app.assign_force([armature.name], is_virtual=True,
                          force_name="ArmatureForce"), "native virtual force")
    need(app.assign_matrix(MatrixMagnetostatic(
        signal_sources=[SourceMagnetostatic(name="CoilAT", turns_number=1)],
        group_sources=[], matrix_name="InductanceMatrix")), "one-turn matrix")

    # Separate real air volumes resolve both working air gaps without filling
    # the whole annular cavity with unnecessarily fine elements.
    central_gap = cylinder("CentralGap", 10, 35, "gap", "vacuum")
    return_gap = cylinder("ReturnGap", 30, 35, "gap", "vacuum")
    gap_tool = cylinder("ReturnGapBoreTool", 25, 35, "gap", "vacuum")
    need(m.subtract(return_gap.name, gap_tool.name, keep_originals=False), "return gap annulus")
    region = need(m.create_box([-75, -75, -50], [150, 150, 150], name="Region", material="vacuum"), "air domain")
    # AEDT's enclosing background region must retain its exterior-only boundary.
    # Nested material objects automatically take priority over background vacuum.
    region = m["Region"]
    region.transparency = 1
    for gap_object in [central_gap, return_gap]:
        gap_object.transparency = 0.85
        gap_object.color = (110, 215, 220)
    need(app.mesh.assign_initial_mesh_from_slider(level=2, method="Auto"), "coarse initial surface mesh")
    need(app.mesh.assign_length_mesh([core.name, armature.name], inside_selection=True,
        maximum_length="4mm" if fine else "5mm", maximum_elements=4500 if fine else 3000,
        name="CoreMesh"), "magnetic core mesh")
    need(app.mesh.assign_length_mesh([coil.name], inside_selection=True,
        maximum_length="4mm", maximum_elements=1200, name="CoilMesh"), "coil mesh")
    need(app.mesh.assign_length_mesh([central_gap.name, return_gap.name], inside_selection=True,
        maximum_length="1.8mm" if fine else "2.5mm", maximum_elements=4000 if fine else 2000,
        name="WorkingGapMesh"), "working gap mesh")
    need(app.create_setup(name="Setup1", MaximumPasses=10,
        MinimumPasses=2, MinimumConvergedPasses=1,
        PercentError=1.0 if fine else 2.0, PercentRefinement=20,
        SolveFieldOnly=False), "magnetostatic adaptive setup")

    meta = {
        "candidate": SPEC, "setup": "Setup1", "solution": "Setup1 : LastAdaptive",
        "geometry": "Full 360-degree 3D axisymmetric pot-core electromagnetic actuator",
        "gap_mm": gap_mm, "physical_current_A": current_a, "turns": turns,
        "amp_turns": turns * current_a, "fine": bool(fine),
        "force_name": "ArmatureForce", "matrix_name": "InductanceMatrix", "source_name": "CoilAT",
        "matrix_turns": 1, "physical_inductance_from_native": "N^2 * one-turn matrix L1",
        "native_energy_relation": "0.5 * L1 * (N*I)^2 = 0.5 * Lphysical * I^2",
        "core_objects": [core.name], "armature_object": armature.name,
        "coil_object": coil.name, "terminal_object": terminal.name,
        "gap_objects": [central_gap.name, return_gap.name], "region_object": region.name,
        "dimensions_mm": {"outer_radius": 30, "core_height": 35, "base_thickness": 5,
            "return_wall_inner_radius": 25, "pole_radius": 10, "coil_inner_radius": 12,
            "coil_outer_radius": 22, "coil_bottom_z": 7, "coil_height": 23, "armature_thickness": 5,
            "air_box_origin": [-75, -75, -50], "air_box_size": [150, 150, 150]},
        "linear_relative_permeability": 1000,
        "assumptions": ["Linear isotropic lossless core; no saturation or hysteresis.",
            "Stranded homogenized DC coil; no thermal or eddy-current solution.",
            "Independent static operating points; no mechanical movement or transient integration.",
            "Finite air domain with native default exterior boundary; no infinite-domain claim.",
            "The magnetic-circuit reference neglects leakage and fringing and is a scale check only."],
        "magnetic_circuit_reference_only": magnetic_circuit_reference(gap_mm, current_a, turns),
        "solver_success": False,
    }
    m.fit_all()
    (out / "actuator3d-build.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    return meta
