"""One fixed actuator case per job; MCP never launches a native desktop."""
from __future__ import annotations

import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import uuid

import psutil
from inventory import JOB_KIND, EXPECTED_CASE_COUNT, RUNNER_NAME, collect_inventory

OUTPUT_PREFIX = 'actuator3d-single-'


def _workspace(path):
    path = Path(path)
    if not path.is_absolute() or not str(path).isascii():
        raise ValueError('MCP workspace must be an absolute ASCII path')
    return path.resolve()


def _job_paths(workspace, job_id):
    if not isinstance(job_id, str) or not re.fullmatch(r'\d{8}-\d{6}-[a-f0-9]{8}', job_id):
        raise ValueError('Invalid job id')
    ledger = (workspace / '.maxwell_jobs').resolve()
    output = (workspace / (OUTPUT_PREFIX + job_id)).resolve()
    log = (ledger / (job_id + '.log')).resolve()
    record = (ledger / (job_id + '.json')).resolve()
    if not ledger.is_relative_to(workspace) or not output.is_relative_to(workspace):
        raise ValueError('Job paths escape workspace')
    if not log.is_relative_to(ledger) or not record.is_relative_to(ledger):
        raise ValueError('Job paths escape ledger')
    return ledger, output, log, record


def start_job(workspace, root, version, student):
    if root is None:
        raise ValueError('Configure --aedt-root before starting a simulation')
    workspace, root = _workspace(workspace), Path(root).resolve()
    if not (root / ('ansysedtsv.exe' if student else 'ansysedt.exe')).is_file():
        raise ValueError('Configured AEDT executable is absent')
    runner = Path(__file__).resolve().with_name(RUNNER_NAME)
    if not runner.is_file():
        raise ValueError('Fixed example runner is absent: ' + RUNNER_NAME)
    # This read-only preflight is mandatory for every start, even if a client
    # already called inventory. No native API connection or launch occurs here.
    inventory = collect_inventory(workspace, root, version, student)
    preflight = inventory.get('attach_only_preflight', {})
    if preflight.get('ready') is not True:
        raise RuntimeError('MCP attach-only preflight failed: ' + str(preflight.get('reason', 'No verified existing desktop')))
    native = preflight['session']
    if psutil.Process(native['pid']).create_time() != native['created_at']:
        raise RuntimeError('Existing AEDT PID changed after inventory; no job was started')
    job_id = time.strftime('%Y%m%d-%H%M%S') + '-' + uuid.uuid4().hex[:8]
    ledger, output, log, record_path = _job_paths(workspace, job_id)
    if output.exists() or log.exists() or record_path.exists():
        raise ValueError('Refusing to reuse existing task output or ledger')
    ledger.mkdir(parents=True, exist_ok=True)
    cmd = [sys.executable, '-B', '-u', '-X', 'utf8', str(runner),
           '--output', str(output), '--aedt-root', str(root), '--version', version,
           '--require-existing']
    if not student:
        cmd.append('--commercial')
    with log.open('xb') as stream:
        process = subprocess.Popen(
            cmd, stdin=subprocess.DEVNULL, stdout=stream, stderr=subprocess.STDOUT,
            cwd=str(workspace), env=dict(os.environ, PYTHONUTF8='1', PYTHONIOENCODING='utf-8'),
            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    try:
        created_at = psutil.Process(process.pid).create_time()
    except psutil.NoSuchProcess:
        created_at = None
    record = {
        'job_id': job_id, 'kind': JOB_KIND, 'pid': process.pid, 'created_at': created_at,
        'output': str(output), 'log': str(log), 'started': time.time(),
        'native_session_preflight': native, 'require_existing': True,
    }
    record_path.write_text(json.dumps(record, indent=2), encoding='utf-8')
    return dict(record, status='starting', expected_case_count=EXPECTED_CASE_COUNT,
                instruction='Poll job_status until completed or failed. The helper attaches only to the existing visible AEDT; it cannot prepare or replace the native desktop.')


def _case_summary(case):
    values, model = case.get('values', {}), case.get('model', {})
    return {
        'design': case['design'], 'values': values,
        'convergence': values.get('native_convergence'),
        'gap_mm': values.get('gap_mm', model.get('gap_mm')),
        'physical_current_A': values.get('physical_current_A', model.get('physical_current_A')),
        'force_xyz_N': values.get('force_xyz_N'), 'physical_L_H': values.get('physical_L_H'),
        'coenergy_from_L_J': values.get('coenergy_from_L_J'),
    }


def read_job(workspace, job_id):
    workspace = _workspace(workspace)
    _, output, log, record_path = _job_paths(workspace, job_id)
    record = json.loads(record_path.read_text(encoding='utf-8'))
    if record.get('kind') != JOB_KIND:
        raise ValueError('Job kind does not match the fixed single-case actuator')
    if (record.get('job_id') != job_id or Path(record['output']).resolve() != output
            or Path(record['log']).resolve() != log or record.get('require_existing') is not True):
        raise ValueError('Job record path or attach-only policy mismatch')
    try:
        running = psutil.Process(record['pid']).create_time() == record['created_at']
    except psutil.NoSuchProcess:
        running = False
    statefile = (output / 'status.json').resolve()
    if not statefile.is_relative_to(output):
        raise ValueError('Result status file escapes job output')
    state = json.loads(statefile.read_text(encoding='utf-8')) if statefile.is_file() else {'status': 'starting'}
    if state.get('kind', JOB_KIND) != JOB_KIND:
        raise ValueError('Result job kind mismatch')
    if state.get('output') and Path(state['output']).resolve() != output:
        raise ValueError('Result output mismatch')
    if state.get('project') and not Path(state['project']).resolve().is_relative_to(output):
        raise ValueError('Result project escapes job output')
    native_pid = record.get('native_session_preflight', {}).get('pid')
    if state.get('pid') is not None and state['pid'] != native_pid:
        raise ValueError('Result AEDT PID differs from the existing desktop preflight')
    cases = state.get('cases', [])
    if not isinstance(cases, list) or len(cases) > EXPECTED_CASE_COUNT:
        raise ValueError('Expected at most one fixed actuator case')
    if state.get('status') == 'completed' and len(cases) != EXPECTED_CASE_COUNT:
        state.update(status='failed', error='Completed result does not contain the one required actuator case')
    if running and state.get('status') == 'completed':
        state['status'] = 'finalizing'
    terminal = state.get('status') in ('completed', 'failed')
    if not running and not terminal:
        state.update(status='interrupted', error='Helper exited before recording a terminal result; no success can be inferred')
    keys = ('status', 'stage', 'elapsed_seconds', 'error', 'project', 'solver_success',
            'physics_verified', 'study_acceptance', 'saved_reread', 'visuals',
            'model_dimension', 'geometry_symmetry')
    summary = {key: state[key] for key in keys if key in state}
    summary['cases'] = [_case_summary(case) for case in cases]
    summary.update(job_id=job_id, kind=JOB_KIND, expected_case_count=EXPECTED_CASE_COUNT,
                   output=str(output), status_file=str(statefile), log=str(log), helper_running=running,
                   require_existing=True, native_session_preflight=record.get('native_session_preflight'))
    if summary.get('status') in ('failed', 'interrupted'):
        summary['log_tail'] = ('\n'.join(log.read_text(encoding='utf-8', errors='replace').splitlines()[-35:])[-6000:]
                               if log.is_file() else 'Helper log is absent')
    return summary
