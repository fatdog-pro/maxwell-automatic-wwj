# Maxwell 3D: single operating point

| Quantity | Native result |
|---|---:|
| case | Nominal_1mm_1A |
| gap_mm | 1.0 |
| current_A | 1.0 |
| turns | 200 |
| attraction_N | 5.48587399764144 |
| inductance_mH | 18.18184639715568 |
| energy_mJ | 9.09092319857784 |
| tetrahedra | 51922 |
| passes | 9 |
| energy_error_percent | 0.79232 |

Linear magnetostatic teaching model. Native fields are in Visuals/.
