$begin 'Profile'
	$begin 'ProfileGroup'
		MajorVer=2025
		MinorVer=2
		Name='Solution Process'
		$begin 'StartInfo'
			I(1, 'Start Time', '10/08/2026 19:56:09')
			I(1, 'Host', 'WWJ-PC')
			I(1, 'Processor', '12')
			I(1, 'OS', 'NT 10.0')
			I(1, 'Product', 'Maxwell 3D 2025.2.4')
		$end 'StartInfo'
		$begin 'TotalInfo'
			I(1, 'Elapsed Time', '00:01:11')
			I(1, 'ComEngine Memory', '70.2 M')
		$end 'TotalInfo'
		GroupOptions=8
		TaskDataOptions(Memory=8)
		ProfileItem('', 0, 0, 0, 0, 0, 'I(1, 1, \'Executing From\', \'E:\\\\AnsysEMStudent\\\\v252\\\\AnsysEM\\\\MAXWELLCOMENGINE.exe\')', false, true)
		$begin 'ProfileGroup'
			MajorVer=2025
			MinorVer=2
			Name='HPC'
			$begin 'StartInfo'
				I(1, 'Type', 'Disabled')
			$end 'StartInfo'
			$begin 'TotalInfo'
				I(0, ' ')
			$end 'TotalInfo'
			GroupOptions=0
			TaskDataOptions(Memory=8)
			ProfileItem('Machine', 0, 0, 0, 0, 0, 'I(4, 1, \'Name\', \'WWJ-PC\', 3, \'RAM Limit\', 90, \'%f%%\', 2, \'Tasks\', 1, false, 2, \'Cores\', 1, false)', false, true)
		$end 'ProfileGroup'
		ProfileItem('Design Validation', 0, 0, 0, 0, 0, 'I(3, 1, \'Level\', \'Perform full validations\', 1, \'Elapsed Time\', \'00:00:00\', 2, \'Memory\', 70948, true)', false, true)
		$begin 'ProfileGroup'
			MajorVer=2025
			MinorVer=2
			Name='Initial Meshing'
			$begin 'StartInfo'
				I(1, 'Time', '10/08/2026 19:56:10')
			$end 'StartInfo'
			$begin 'TotalInfo'
				I(1, 'Elapsed Time', '00:00:04')
			$end 'TotalInfo'
			GroupOptions=4
			TaskDataOptions(Memory=8)
			ProfileItem('Mesh', 2, 0, 1, 0, 54000, 'I(2, 2, \'Tetrahedra\', 15375, false, 1, \'Type\', \'TAU\')', true, true)
			ProfileItem('Coarsen', 1, 0, 1, 0, 54000, 'I(1, 2, \'Tetrahedra\', 2276, false)', true, true)
			ProfileItem('Manual Refine', 1, 0, 1, 0, 38924, 'I(2, 2, \'Tetrahedra\', 12051, false, 0, \'CoilMesh, CoreMesh, WorkingGapMesh\')', true, true)
		$end 'ProfileGroup'
		$begin 'ProfileGroup'
			MajorVer=2025
			MinorVer=2
			Name='Adaptive Meshing'
			$begin 'StartInfo'
				I(1, 'Time', '10/08/2026 19:56:14')
			$end 'StartInfo'
			$begin 'TotalInfo'
				I(1, 'Elapsed Time', '00:01:06')
			$end 'TotalInfo'
			GroupOptions=4
			TaskDataOptions(Memory=8)
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Pass 1'
				$begin 'StartInfo'
					I(0, '')
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('Matrix Solve', 0, 0, 0, 0, 52683, 'I(4, 1, \'Type\', \'DRS\', 2, \'Cores\', 1, false, 2, \'Matrix\', 16313, false, 1, \'Disk\', \'0KB\')', true, true)
				ProfileItem('adapt', 1, 0, 1, 0, 225248, 'I(1, 2, \'Tetrahedra\', 12051, false)', true, true)
			$end 'ProfileGroup'
			ProfileItem('', 0, 0, 0, 0, 0, 'I(1, 0, \'\')', false, true)
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Pass 2'
				$begin 'StartInfo'
					I(0, '')
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('Adaptive Refine', 0, 0, 0, 0, 36292, 'I(1, 2, \'Tetrahedra\', 14465, false)', true, true)
				ProfileItem('Matrix Solve', 0, 0, 0, 0, 71708, 'I(4, 1, \'Type\', \'DRS\', 2, \'Cores\', 1, false, 2, \'Matrix\', 19724, false, 1, \'Disk\', \'0KB\')', true, true)
				ProfileItem('adapt', 2, 0, 1, 0, 241888, 'I(1, 2, \'Tetrahedra\', 14465, false)', true, true)
			$end 'ProfileGroup'
			ProfileItem('', 0, 0, 0, 0, 0, 'I(1, 0, \'\')', false, true)
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Pass 3'
				$begin 'StartInfo'
					I(0, '')
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('Adaptive Refine', 0, 0, 0, 0, 38044, 'I(1, 2, \'Tetrahedra\', 17366, false)', true, true)
				ProfileItem('Matrix Solve', 0, 0, 0, 0, 92600, 'I(4, 1, \'Type\', \'DRS\', 2, \'Cores\', 1, false, 2, \'Matrix\', 23682, false, 1, \'Disk\', \'0KB\')', true, true)
				ProfileItem('adapt', 2, 0, 1, 0, 257908, 'I(1, 2, \'Tetrahedra\', 17366, false)', true, true)
			$end 'ProfileGroup'
			ProfileItem('', 0, 0, 0, 0, 0, 'I(1, 0, \'\')', false, true)
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Pass 4'
				$begin 'StartInfo'
					I(0, '')
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('Adaptive Refine', 0, 0, 0, 0, 40492, 'I(1, 2, \'Tetrahedra\', 20844, false)', true, true)
				ProfileItem('Matrix Solve', 0, 0, 1, 0, 123876, 'I(4, 1, \'Type\', \'DRS\', 2, \'Cores\', 1, false, 2, \'Matrix\', 28371, false, 1, \'Disk\', \'0KB\')', true, true)
				ProfileItem('adapt', 3, 0, 1, 0, 277024, 'I(1, 2, \'Tetrahedra\', 20844, false)', true, true)
			$end 'ProfileGroup'
			ProfileItem('', 0, 0, 0, 0, 0, 'I(1, 0, \'\')', false, true)
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Pass 5'
				$begin 'StartInfo'
					I(0, '')
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('Adaptive Refine', 1, 0, 1, 0, 44456, 'I(1, 2, \'Tetrahedra\', 25023, false)', true, true)
				ProfileItem('Matrix Solve', 1, 0, 0, 0, 140415, 'I(4, 1, \'Type\', \'DRS\', 2, \'Cores\', 1, false, 2, \'Matrix\', 33985, false, 1, \'Disk\', \'0KB\')', true, true)
				ProfileItem('adapt', 3, 0, 2, 0, 297696, 'I(1, 2, \'Tetrahedra\', 25023, false)', true, true)
			$end 'ProfileGroup'
			ProfileItem('', 0, 0, 0, 0, 0, 'I(1, 0, \'\')', false, true)
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Pass 6'
				$begin 'StartInfo'
					I(0, '')
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('Adaptive Refine', 1, 0, 1, 0, 50900, 'I(1, 2, \'Tetrahedra\', 30036, false)', true, true)
				ProfileItem('Matrix Solve', 0, 0, 1, 0, 195095, 'I(4, 1, \'Type\', \'DRS\', 2, \'Cores\', 1, false, 2, \'Matrix\', 40767, false, 1, \'Disk\', \'0KB\')', true, true)
				ProfileItem('adapt', 5, 0, 2, 0, 324376, 'I(1, 2, \'Tetrahedra\', 30036, false)', true, true)
			$end 'ProfileGroup'
			ProfileItem('', 0, 0, 0, 0, 0, 'I(1, 0, \'\')', false, true)
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Pass 7'
				$begin 'StartInfo'
					I(0, '')
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('Adaptive Refine', 1, 0, 1, 0, 54836, 'I(1, 2, \'Tetrahedra\', 36046, false)', true, true)
				ProfileItem('Matrix Solve', 1, 0, 1, 0, 218763, 'I(4, 1, \'Type\', \'DRS\', 2, \'Cores\', 1, false, 2, \'Matrix\', 48849, false, 1, \'Disk\', \'0KB\')', true, true)
				ProfileItem('adapt', 4, 0, 3, 0, 355272, 'I(1, 2, \'Tetrahedra\', 36046, false)', true, true)
			$end 'ProfileGroup'
			ProfileItem('', 0, 0, 0, 0, 0, 'I(1, 0, \'\')', false, true)
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Pass 8'
				$begin 'StartInfo'
					I(0, '')
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('Adaptive Refine', 1, 0, 1, 0, 60524, 'I(1, 2, \'Tetrahedra\', 43262, false)', true, true)
				ProfileItem('Matrix Solve', 1, 0, 1, 0, 270226, 'I(4, 1, \'Type\', \'DRS\', 2, \'Cores\', 1, false, 2, \'Matrix\', 58540, false, 1, \'Disk\', \'0KB\')', true, true)
				ProfileItem('adapt', 5, 0, 4, 0, 390284, 'I(1, 2, \'Tetrahedra\', 43262, false)', true, true)
			$end 'ProfileGroup'
			ProfileItem('', 0, 0, 0, 0, 0, 'I(1, 0, \'\')', false, true)
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Pass 9'
				$begin 'StartInfo'
					I(0, '')
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('Adaptive Refine', 1, 0, 1, 0, 68992, 'I(1, 2, \'Tetrahedra\', 51922, false)', true, true)
				ProfileItem('Matrix Solve', 2, 0, 1, 0, 319349, 'I(4, 1, \'Type\', \'DRS\', 2, \'Cores\', 1, false, 2, \'Matrix\', 70184, false, 1, \'Disk\', \'0KB\')', true, true)
				ProfileItem('adapt', 4, 0, 4, 0, 433960, 'I(1, 2, \'Tetrahedra\', 51922, false)', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='InductanceMatrix'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('Matrix Solve', 1, 0, 1, 0, 319349, 'I(4, 1, \'Type\', \'DRS\', 2, \'Cores\', 1, false, 2, \'Matrix\', 70184, false, 1, \'Disk\', \'0KB\')', true, true)
				ProfileItem('Param', 4, 0, 3, 0, 446352, 'I(1, 2, \'Tetrahedra\', 51922, false)', true, true)
			$end 'ProfileGroup'
			ProfileFootnote('I(1, 0, \'Adaptive Passes converged\')', 0)
		$end 'ProfileGroup'
		ProfileFootnote('I(2, 1, \'Stop Time\', \'10/08/2026 19:57:21\', 1, \'Status\', \'Normal Completion\')', 0)
	$end 'ProfileGroup'
$end 'Profile'
